#ifndef DIALOGSONGLISTOP_H
#define DIALOGSONGLISTOP_H

#include <QDialog>

namespace Ui {
class DialogSongListOp;
}

class DialogSongListOp : public QDialog
{
    Q_OBJECT
public:
    int newSongListOp();
    void deleteSongListOp();
    explicit DialogSongListOp(QWidget *parent = nullptr);
    ~DialogSongListOp();
signals:
    void pushButtonNewSongList_clicked();
    void showMenu(QPushButton* p);
    void NewSongList();
protected slots:
    void pushButtonNewSongList_isclicked(){
        emit NewSongList();
    }
private slots:
    void on_pushButtonNewSongList_clicked();

    void on_pushButtonDeleteSongList_clicked();

    void on_pushButtonQuit_clicked();

private:
    Ui::DialogSongListOp *ui;
};

#endif // DIALOGSONGLISTOP_H
