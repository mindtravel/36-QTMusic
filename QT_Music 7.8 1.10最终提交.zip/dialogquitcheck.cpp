#include "dialogquitcheck.h"
#include "ui_dialogquitcheck.h"

DialogQuitCheck::DialogQuitCheck(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogQuitCheck)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

DialogQuitCheck::~DialogQuitCheck()
{
    delete ui;
}
