#include "dialognewsonglist.h"
#include "ui_dialognewsonglist.h"

#include "widget.h"
#include "ui_widget.h"

DialogNewSongList::DialogNewSongList(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogNewSongList)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

DialogNewSongList::~DialogNewSongList()
{
    delete ui;
}

void DialogNewSongList::on_pushButtonYse_clicked()
{
    Widget* w=new Widget(this->parentWidget());
    if(this->ui->lineEdit->text().isEmpty()){
        this->ui->labelWarning->setText("名称为空！");
        return;
    }
    for(auto i:w->songList.l){
        if(this->ui->lineEdit->text()==i.name){
            this->ui->labelWarning->setText("与已有歌单名称重复！");
            return;
        }
    }
    w->setSongList(this->ui->lineEdit->text());
    w->addRightMenu();
    w->show();
    this->close();
}


void DialogNewSongList::on_lineEdit_textChanged(const QString &arg1)
{
    this->ui->labelWarning->setText("");
}


void DialogNewSongList::on_pushButtonNo_clicked()
{
    Widget* w=new Widget(this->parentWidget());
    w->addRightMenu();
    w->show();
    this->close();
}

