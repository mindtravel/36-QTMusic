#ifndef DIALOGDELETESONGLIST_H
#define DIALOGDELETESONGLIST_H

#include <QDialog>

namespace Ui {
class DialogDeleteSongList;
}

class DialogDeleteSongList : public QDialog
{
    Q_OBJECT

public:
    explicit DialogDeleteSongList(QWidget *parent = nullptr);
    ~DialogDeleteSongList();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::DialogDeleteSongList *ui;
};

#endif // DIALOGDELETESONGLIST_H
