/*
主题：Qt大作业
功能：音乐播放器
作者：袁煦校
*/
#ifndef MP3INFO_H
#define MP3INFO_H

#include <iostream>
#include <fstream>
#include <vector>
#include <qstring.h>
#include <QDebug>>
//注意这个头文件
#include <io.h>
using namespace std;
QString correctQString(string str){
    return QString::fromStdString(str).remove(QChar('\u0000'));
}


//标签头：10字节
struct TagHead{
    char header[3]; //标签（必须为ID3）
    char version; //版本号
    char reversion; //副版本号
    char flag; //标志
    char size[4]; //标签大小
    string get_header(){
        string str;
        str = str.append(header,header+3);
        return str;
    }
}tagHead;

//标签帧帧头：10字节
struct FrameHead{
    char id[4]; //标识帧
    char size[4]; //帧内容大小
    char flags[2]; //标志帧
    string getId(){
        string str;
        str.append(id,id+4);
        return str;
    }
    int getSize(){
        //每个字节只使用后七位
        // return (size[3]&127) + (size[2]&127)*(1<<7) +
        //        (size[1]&127)*(1<<14) + (size[0]&127)*(1<<21);

        //每个字节使用八位
        return (size[3]&255) + (size[2]&255)*(1<<8) +
               (size[1]&255)*(1<<16) + (size[0]&255)*(1<<24);
    }
}frameHead;
//struct CoverInfo{
//    unsigned char Header[3];
//    char FrameId[4];     //存放帧标识
//    unsigned char Header_size[4];
//    unsigned int mp3_TagSize;
//    unsigned char frameSize[4];      //存放该帧内容的大小
//    unsigned int framecount;
//    int coverBegin;
//    int coverEnd;
//    int coverLength;
//    QString coverType;
//    QString coverUrl;
//};
//mp3歌曲信息（通过ID3V2读取）
class Mp3Info{
private:
    int id;
    QString qFileName;
    QString qTitle;
    QString qAuthor;
    QString qYear;
    QString qTypee;
    QString qAlbum;
    QString qDuration;
    string fileName;
    string title;//歌曲标题
    string author;//歌曲作者
    string year;//歌曲年份
    string type;//歌曲类型
    string album;//歌曲专辑
    int duration;//歌曲时长
    //CoverInfo coverInfo;
    static const string DEFAULT;
    static const string Info[5];
    static const string coverSign;
public:
    Mp3Info():fileName(DEFAULT),title(DEFAULT),author(DEFAULT),year(DEFAULT),type(DEFAULT),album(DEFAULT){}
    Mp3Info(string file,string _title,string _author,string _year,string _type,string _album):
        fileName(file),title(_title),author(_author),year(_year),type(_type),album(_album){}
    Mp3Info(string file):fileName(file),title(DEFAULT),author(DEFAULT),year(DEFAULT),type(DEFAULT),album(DEFAULT){
        getInfo(file);
    }
    void writeId(int _id){
        id=_id;
    }
    int getId(){
        return id;
    }
    string getTitle(){return title;}
    string getAuthor(){return author;}
    string getYear(){return year;}
    string getType(){return type;}
    string getAlbum(){return album;}
    QString getQTitle(){return qTitle;}
    QString getQAuthor(){return qAuthor;}
    QString getQYear(){return qYear;}
    QString getQType(){return qTypee;}
    QString getQAlbum(){return qAlbum;}
    QString getQDuration(){
        int m,s,temp;
        temp=duration/1000;
        m = temp/60;
        s = temp-m*60;
        return QString("%1:%2").arg(m, 2, 10, QLatin1Char('0')).arg(s, 2, 10, QLatin1Char('0'));
    }
    void writeDuration(int t){duration=t;}
    void getInfo(string file); //按输入文件名提取信息
    void writeInfo(string id, string content); //将读到的信息写入类成员变量中
    void printInfo(); //输出歌曲信息
    //void getCover();
};
const string Mp3Info::DEFAULT = "--";
const string Mp3Info::Info[5]{"TIT2","TPE1","TYER","TCON","TALB"};
const string Mp3Info::coverSign{"APIC"};
//按输入文件名提取信息
void Mp3Info::getInfo(string file){
    //补充后缀名
    string str = file.substr(file.length()-4, 4);
    if (str!=".mp3" && str!=".MP3") file += ".mp3";

    //二进制方式打开文件
    ifstream mp3File(file, ios::in|ios::binary);
    if (!mp3File) {
        ;//cout << "File Open Failed" << endl;
        return;
    } //else cout << "File Open Succeeded" << endl;

    //读入标签头
    mp3File.read((char*)&tagHead, sizeof(TagHead));
    if (tagHead.get_header() != "ID3") {
        ;//cout << "Cannot Find Infomation" << endl;
        return;
    } //else cout << "Infomation Reading started" << endl;

    //读入标签帧
    //int x=0;
    char *p;
    while(1){
        //读入标签帧帧头
        mp3File.read((char*)&frameHead, sizeof(FrameHead));
        if (frameHead.getId()[0] == 0) break;

        //输出帧头内容与帧头大小
        //         cout << "Infomation " << ++x << endl;
        //         cout << frameHead.getId() << endl;
        //         cout << frameHead.getSize() << endl;

        //读入帧内容
        if (!p) delete []p;
        p = new char[frameHead.getSize()+1];
        mp3File.read(p, frameHead.getSize());
        string str;
        str.append(p, p+frameHead.getSize());

        // if (str.length() <= 256) cout << str << endl;
        writeInfo(frameHead.getId(), str);
    }

    mp3File.close();
}
//将读到的信息写入类成员变量中
void Mp3Info::writeInfo(string id, string content){
    //强行删掉前三个乱码（01 FE FF），非常不严谨的操作
    if (content[0] == 1){
        //qDebug()<<"content="<<content;
        content = content.substr(3, content.length()-3);
    }
    //输出信息
    if (id == Mp3Info::Info[0]) title = content;
    else if (id == Mp3Info::Info[1]) author = content;
    else if (id == Mp3Info::Info[2]) year = content;
    else if (id == Mp3Info::Info[3]) type = content;
    else if (id == Mp3Info::Info[4]) album = content;
    //else if (id == Mp3Info::coverSign) getCover();
    qTitle=correctQString(title);
    qAuthor=correctQString(author);
    qTypee=correctQString(type);
    qAlbum=correctQString(album);
    qYear=correctQString(year);

}
//输出歌曲信息
//void Mp3Info::getCover(){
//    unsigned int i = 10;
////    fseek(fp,i,SEEK_SET);
////    fread(&FrameId,1,4,fp);
//    fseek(fp,4+i,SEEK_SET);
//    fread(&this->coverInfo.frameSize,1,4,fp);
//    this->coverInfo.framecount = this->coverInfo.frameSize[0]*0x1000000+this->coverInfo.frameSize[1]*0x10000+this->coverInfo.frameSize[2]*0x100+this->coverInfo.frameSize[3];
//    //qDebug()<<"framecount:"<<framecount;
//    QString aa="";
//    aa+=this->coverInfo.FrameId[0];
//    aa+=this->coverInfo.FrameId[1];
//    aa+=this->coverInfo.FrameId[2];
//    aa+=this->coverInfo.FrameId[3];
//    //qDebug()<<"aa:"<<aa;
//    this->coverInfo.coverBegin = i+10;
//    aa;
//    i +=(10+this->coverInfo.framecount);
//    this->coverInfo.coverEnd = i;
//    .FrameId.insert(aa,m_struct);
//    int length = this->coverInfo.coverEnd-this->coverInfo.coverBegin;
//    unsigned char temp[20] = {0};
//    fseek(fp,this->coverInfo.coverBegin,SEEK_SET);
//    fread(&temp,1,20,fp);
//    int tank=0;
//    int j = 0;
//    int pictureFlag=0;
//    while(1)
//    {
//        if((temp[j] == 0xff)&&(temp[j+1] == 0xd8)){
//            tank = j;
//            pictureFlag=1;
//            this->coverInfo.coverType = ".jpg";
//            qDebug()<<"jpeg";
//            qDebug()<<"j:"<<j;
//            break;
//        }else if((temp[j] == 0x89)&&(temp[j+1] == 0x50)){
//            tank = j;
//            pictureFlag=2;
//            this->coverInfo.coverType = ".png";
//            qDebug()<<"png";
//            qDebug()<<"j:"<<j;
//            break;
//        }
//        j++;
//    }
//    //qDebug()<<"frameSize:"<<i;         //10+i为frameid自己的首地址
//    unsigned char t[length] = {0};
//    fseek(fp,this->coverInfo.coverBegin+tank,SEEK_SET);
//    this->coverInfo.coverBegin = this->coverInfo.coverBegin+tank;
//    this->coverInfo.coverLength = length;
//    fread(&t,1,length,fp);
////    if(pictureFlag==1)          //jpeg
////    {
////        QString temp_1 = "C:/Users/Admin/Desktop/new_text";
////        QString temp_2 = QString::number(songNumber,10);
////        temp_1+=temp_2;
////        temp_1+=".jpg";
////        mp3Info->coverUrl = temp_1;
////        if(songNumber<3)
////        {
////            std::string str_temp = temp_1.toStdString();
////            const char *ch = str_temp.c_str();
////            FILE *fpw = fopen( ch, "wb" );
////            fwrite(&t,lenth,1,fpw);
////            fclose(fpw);     //是否也需要关掉fp
////        }

////    }else if(pictureFlag==2)        //png
////    {
////设置文件路径
////        QString temp_1 = "C:/Users/Admin/Desktop/new_text";
////        QString temp_2 = QString::number(songNumber,10);
////        temp_1+=temp_2;
////        temp_1+=".png";
////        mp3Info->coverUrl = temp_1;
////        if(songNumber<4)
////        {
////            std::string str_temp = temp_1.toStdString();
////            const char *ch = str_temp.c_str();
////            FILE *fpw = fopen( ch, "wb" );
////            fwrite(&t,length,1,fpw);
////            fclose(fpw);     //是否也需要关掉fp
////            fclose(fp);
////        }

////    }
//}

//};
void Mp3Info::printInfo(){
    qDebug() << "Title:   " << title;
    qDebug() << "Author:  " << author;
    qDebug() << "Year:    " << year;
    qDebug() << "Type:    " << type;
    qDebug()<< "Album:   " << album;
    qDebug()<< "Duration:   " << duration;
    qDebug();
}

void getFileNames(string path, vector<string>& files)
{

    //文件句柄
    //注意：我发现有些文章代码此处是long类型，实测运行中会报错访问异常
    intptr_t hFile = 0;
    //文件信息
    struct _finddata_t fileinfo;
    string p;//qDebug()<< _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo);
    if ((hFile = _findfirst(p.assign(path).append("/*").c_str(), &fileinfo)) != -1)
    {
        do
        {
            //如果是目录,递归查找
            //如果不是,把文件绝对路径存入vector中
            if ((fileinfo.attrib & _A_SUBDIR))
            {
                if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
                    getFileNames(p.assign(path).append("/").append(fileinfo.name), files);
            }
            else
            {
                files.push_back(p.assign(path).append("/").append(fileinfo.name));//qDebug()<<p;
            }
        } while (_findnext(hFile, &fileinfo) == 0);
        _findclose(hFile);
    }
}

#endif  // MP3INFO_H
