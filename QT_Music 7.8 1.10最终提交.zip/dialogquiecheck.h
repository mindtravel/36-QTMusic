#ifndef DIALOGQUIECHECK_H
#define DIALOGQUIECHECK_H

#include <QDialog>

namespace Ui {
class DialogQuieCheck;
}

class DialogQuieCheck : public QDialog
{
    Q_OBJECT

public:
    explicit DialogQuieCheck(QWidget *parent = nullptr);
    ~DialogQuieCheck();

private:
    Ui::DialogQuieCheck *ui;
};

#endif // DIALOGQUIECHECK_H
