#include "qdebug.h"
#include<vector>
#include <time.h>
#include<iostream>
class SongOrder{
//private:
    int order;//正在播放的歌曲在表单中的位置
    int atPlay; //正在播放的歌曲的绝对编号
    int num;//表单中歌曲的总数
    int playMode;//播放模式
    QString source;//v歌曲来源
    QString sourceTemp;//vTemp歌曲来源
    std::vector<int> v;//正在播放的歌曲序列
    std::vector<int> vTemp;//待播放的歌曲序列
public:
    SongOrder(){
        playMode=0;
        num=0;
        std::srand(time(nullptr));
    };
    ~SongOrder(){};
    //获取vTemp歌曲总数
    int getNumTemp(){
        return vTemp.size();
    }
    //获取v歌曲总数
    int getNum(){
        return v.size();
    }
    //用序号检索vTemp中歌曲
    int getSongTemp(int index){
        if(index>=0&&index<(int)vTemp.size()){
            return vTemp[index];
        }
        else return -1;
    }
    //用序号检索v中歌曲
    int getSong(int index){
        if(index>=0&&index<(int)v.size()){
            return v[index];
        }
        else return -1;
    }
    //设置v播放队列
    void setOrder(int index){
        v=vTemp;
        num=v.size();
        source=sourceTemp;
        set(index);
    }
    //设置vTemp播放队列
    void setOrderTemp(std::vector<int> v0){
        vTemp=v0;
    }
    //设置vTemp歌曲来源
    void setSourceTemp(QString str){
        sourceTemp=str;
    }
    //获取顺序号
    int getOrder(){
        return order;
    }
    //获取绝对编号
    int getAtPlay(){
        return atPlay;
    }
    //获取v歌曲来源
    QString getSource(){
        return source;
    }
    //添加歌曲
    void addSong(int index){
        v.push_back(index);
        num++;
    }
    //清空v
    void clear(){
        v.clear();
        num=0;
    }
    //上一首
    void lastSong(){
        if(!v.empty())
            switch (playMode){
            case 0:{//顺序播放，有上一首下一首
                if(order==0){
                    order=num-1;
                }
                else order--;
                atPlay=v[order];
                break;
            }
            case 1:{//单曲循环，不变
                break;
            }
            case 2:{//随机播放，随机选择
                if(num!=1){
                    int _order=order;
                    do{
                        order=rand()%num;
                    }while(_order==order);
                }
                atPlay=v[order];
                break;
            }
            }
    }
    //下一首
    void nextSong(){
        if(!v.empty())
            qDebug()<<"换歌";
            switch (playMode){
            case 0:{//顺序播放，有上一首下一首
                if(order==num-1){
                    order=0;
                }
                else order++;
                atPlay=v[order];
                break;
            }
            case 1:{//单曲循环，不变
                break;
            }
            case 2:{//随机播放，随机选择
                if(num!=1){
                    int _order=order;
                    do{
                        order=rand()%num;
                    }while(_order==order);
                }
                atPlay=v[order];
                break;
            }
            }
    }
    //设置播放方式
    void setPlayMode(int index){
        playMode=index;
    }
    //设置播放的曲目
    void set(int index){
        if(index<0||index>num-1){
            std::cout<<"error"<<std::endl;
            return;
        }
        order=index;
        atPlay=v[index];
    }
    //获取v是否为空
    bool getVEmpty(){
        return v.empty();
    }

    //打印v，测试用
    void printList(){
        if(!v.empty()){
            //            std::cout<<"playMode="<<playMode<<std::endl;
            //            std::cout<<"num="<<num<<std::endl;
            qDebug()<<"playMode="<<playMode;
            qDebug()<<"num="<<num;
            for(auto i:v){
                qDebug()<<i<<" ";
                //std::cout<<i<<" " ;
            }
            qDebug();
            //std::cout<<std::endl;
        }
    }
};
