#include "dialogsongop.h"
#include "ui_dialogsongop.h"
#include <QPushbutton>
DialogSongOp::DialogSongOp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSongOp)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
};

DialogSongOp::~DialogSongOp(){
    delete ui;
}

void DialogSongOp::on_buttonBox_accepted(){
    qDebug()<<"accepted";
    //    Widget* w=new Widget(this->parentWidget());
    //    //    for(auto i:w->songList.deleted){
    //    //        qDebug()<<i;
    //    //    }

    //    w->songList.deleteSongList();
    //    w->songList.readFile();
    //    w->songList.showSongList(w->ui->tableWidgetSongList);
    //    w->setManage(0);
    //    w->show();
    this->close();
}


void DialogSongOp::on_buttonBox_rejected(){
    qDebug()<<"rejected";
    //    Widget* w=new Widget(this->parentWidget());
    //    //回到原来的tableWidgetSongList
    //    w->ui->tableWidgetSongList->insertColumn(1);
    //    w->ui->tableWidgetSongList->setHorizontalHeaderLabels(QStringList() << "名称" << "删除");
    //    w->ui->tableWidgetSongList->setColumnWidth(1, 30);

    //    //w->songList.deleteSongList(false);
    //    w->setManage(1);
    //    w->show();
    this->close();
}
