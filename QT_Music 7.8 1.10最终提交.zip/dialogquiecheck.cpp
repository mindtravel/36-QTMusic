#include "dialogquiecheck.h"
#include "ui_dialogquiecheck.h"

DialogQuieCheck::DialogQuieCheck(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogQuieCheck)
{
    ui->setupUi(this);
}

DialogQuieCheck::~DialogQuieCheck()
{
    delete ui;
}
