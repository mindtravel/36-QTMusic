#include "widget.h"
#include "ui_widget.h"

#include "dialogdeletesonglist.h"
#include "ui_dialogdeletesonglist.h"

DialogDeleteSongList::DialogDeleteSongList(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogDeleteSongList)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

DialogDeleteSongList::~DialogDeleteSongList()
{
    delete ui;
}

void DialogDeleteSongList::on_buttonBox_accepted()
{
//    qDebug()<<"accepted";
    Widget* w=new Widget(this->parentWidget());
//    for(auto i:w->songList.deleted){
//        qDebug()<<i;
//    }
    w->songList.deleteSongList();
    w->songList.readFile();
    w->songList.showSongList(w->ui->tableWidgetSongList);
    w->setManage(0);
    w->show();
    this->close();
}


void DialogDeleteSongList::on_buttonBox_rejected()
{
//    qDebug()<<"rejected";
    Widget* w=new Widget(this->parentWidget());
    //回到原来的tableWidgetSongList
    w->ui->tableWidgetSongList->insertColumn(1);
    w->ui->tableWidgetSongList->setHorizontalHeaderLabels(QStringList() << "名称" << "删除");
    w->ui->tableWidgetSongList->setColumnWidth(1, 30);

    //w->songList.deleteSongList(false);
    w->setManage(1);
    w->show();
    this->close();
}

