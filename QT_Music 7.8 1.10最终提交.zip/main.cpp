#include "widget.h"
#include <QTimer.h>
#include <QApplication>
int xPage1=0,yPage1=0;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.readSongs();
    w.addRightMenu();
    w.show();

//    QTimer timer1,timer2;
//    timer1.setInterval(20);  // 每20ms触发一次
//    //timer2.setInterval(500);  // 每1s触发一次
//    timer1.start();
//    // 连接定时器的timeout()信号到槽函数
//    QObject::connect(&timer1, &QTimer::timeout, [&]() {
//        //if(!image.isNull()){
//            w.getAlbumPosition();
//            w.movePage1();
//            w.continueSong();
//            w.setSliderTime();
//            w.setTime();
//            //qDebug() << "xAlbum="<<xAlbum<<"    yAlbum="<<yAlbum;
//        //}
//    });

    // 执行主事件循环，阻塞程序的执行
    return a.exec();
}
