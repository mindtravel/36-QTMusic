#ifndef WIDGET_H
#define WIDGET_H
#include "songOrder.h"
#include "mouse.h"
#include <songlist.h>

#include <QWidget>
#include <QLabel.h>
#include <QTimer.h>
#include <QMediaPlayer.h>
#include <QAudioOutput.h>
#include <qcompleter.h>
#include <QPushbutton.h>
#include <qcheckbox.h>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
//必要的控件
    QString path;
    QSize albumSize;
    QFont font;
    QMediaPlayer *player;
    QAudioOutput *audioOutput;
    QCompleter *qCompleter;
    QPixmap qPixmap;
    QPalette* qPalette;
    //右键菜单，用于将歌曲添加进歌单
    int selectedRow;
    void addRightMenu();
    //声明动作
    QAction* buttonAction;
    std::vector<QAction*> v;
    //声明菜单
    QMenu * buttonMenu;
    SongOrder songOrder{};//歌曲序号类
    SongList songList{};//歌单类
//时间相关
    qint64 duration;//正在播放的歌曲的总时间
    qint64 positionNow;//正在播放的歌曲的当前时间
    QTimer timerSong;
    QTimer timer;
//初始化
    void setSearchCompleter();
    void setPicture(QPushButton* p,int index);
    void setLabelFont(QLabel* p);
//从文件中读取歌曲
    void readSongs();
//需要依据时钟反复更新的操作，20ms更新一次
    void timeOp();
//移动开始界面的组件
    void setAlbumPosition(QPixmap& qPixmap);
    void openAlbumImage();//打开专辑图片
    void getAlbumPosition();//设置专辑图片的位置
    void movePage1();//依据专辑图片的位置，移动开始界面的组件
//歌曲信息表tableWidget
    void clearList();//清空tableWidget
    void addSongIntoList();//添加歌曲到播放列表
    void addSongIntoListTemp();//添加歌曲到展示列表
//歌曲播放
    void setstackedWidget1();//将歌曲信息导入开始界面
    void playsong();//播放歌曲
    void setSliderTime();//歌曲时间->horizontalSliderTime

    void continueSong();
    void setTime();
    void SearchSong(QString &str);
//打开新dialog窗口
    int openSongListOp();//打开DialogSongListOp
    int openSongOp();//打开DialogSongOp
    int openDeleteCheck();//打开DialogDeleteCheck
//歌单功能
    void setManage(int index);//设置歌单管理模式
    void setSongList(QString str);//新建名称为str的歌单
    void openSongList(int index);//打开序号为index的歌单

    int test();
private slots:
    void on_pushButton_clicked();

    void on_pushButtonSearch_clicked();

    void on_toolBox_currentChanged(int index);

    void on_tableWidget_cellDoubleClicked(int row, int column);

    void on_pushButtonPlayorStop_clicked();

    void on_horizontalSliderTime_sliderMoved(int position);

    void on_pushButtonLastSong_clicked();

    void on_pushButtonNextSong_clicked();

    void on_verticalSlider_sliderMoved(int position);

    void on_comboBoxPlayMode_currentIndexChanged(int index);

    void on_verticalSliderVolume_sliderMoved(int position);
    void on_comboBoxPlayMode_activated(int index);

    void on_pushButtonManage_clicked();

    void on_tableWidget_cellClicked(int row, int column);

    void on_tableWidgetSongList_cellClicked(int row, int column);

    void on_tableWidget_cellEntered(int row, int column);

    void on_tableWidget_cellActivated(int row, int column);

    void on_pushButtonManageList_clicked();

    void on_pushButtonSetAudio_clicked();

    void on_pushButtonLoadSong_clicked();

public:
    Ui::Widget *ui;
};
#endif // WIDGET_H
