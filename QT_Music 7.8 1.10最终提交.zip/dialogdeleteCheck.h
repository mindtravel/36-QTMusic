#ifndef DIALOGDELETECHECK_H
#define DIALOGDELETECHECK_H

#include <QDialog>

namespace Ui {
class DialogDeleteCheck;
}

class DialogDeleteSong : public QDialog
{
    Q_OBJECT

public:
    explicit DialogDeleteSong(QWidget *parent = nullptr);
    ~DialogDeleteSong();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::DialogDeleteCheck *ui;
};

#endif // DIALOGDELETECHECK_H
