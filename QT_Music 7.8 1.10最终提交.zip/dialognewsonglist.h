#ifndef DIALOGNEWSONGLIST_H
#define DIALOGNEWSONGLIST_H

#include <QDialog>

namespace Ui {
class DialogNewSongList;
}

class DialogNewSongList : public QDialog
{
    Q_OBJECT

public:
    explicit DialogNewSongList(QWidget *parent = nullptr);
    ~DialogNewSongList();

private slots:
    void on_pushButtonYse_clicked();

    void on_lineEdit_textChanged(const QString &arg1);

    void on_pushButtonNo_clicked();

private:
    Ui::DialogNewSongList *ui;
};

#endif // DIALOGNEWSONGLIST_H
